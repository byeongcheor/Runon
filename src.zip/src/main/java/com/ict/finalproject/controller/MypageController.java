package com.ict.finalproject.controller;

import com.ict.finalproject.dto.CustomUserDetails;
import com.ict.finalproject.service.MemberService;
import com.ict.finalproject.service.MypageService;
import com.ict.finalproject.vo.MemberVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;


@Slf4j
@Controller
public class MypageController {
    @Autowired
    MypageService service;
    @Autowired
    MemberService memberService;


   @GetMapping("mypage/myHome")
    public String myHome(Model model, MemberVO mvo){
        // 인증된 사용자 정보 가져오기
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();

        String username = userDetails.getUsername();
        String email = mvo.getEmail();
        String profileImage = mvo.getProfile_img();

        model.addAttribute("username", username);
        model.addAttribute("email", email);
        model.addAttribute("profileImage", profileImage);

        return "mypage/myHome";
    }
}
