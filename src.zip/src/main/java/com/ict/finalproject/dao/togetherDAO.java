package com.ict.finalproject.dao;


import com.ict.finalproject.vo.TogetherVO;

import java.util.List;

public interface togetherDAO {

    // public List<TogetherVO> selectAll();;
}
