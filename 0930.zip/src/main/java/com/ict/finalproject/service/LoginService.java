package com.ict.finalproject.service;

public interface LoginService {
    public void addToken(String refreshToken,String username);

}
