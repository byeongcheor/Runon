package com.ict.finalproject.service;

import com.ict.finalproject.vo.TogetherVO;

import java.util.List;

public interface togetherService {

    //public List<TogetherVO> selectAll();
}
