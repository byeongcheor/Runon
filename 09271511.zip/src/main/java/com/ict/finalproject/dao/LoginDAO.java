package com.ict.finalproject.dao;

public interface LoginDAO {
    public void addToken(String refreshToken,String username);
}
