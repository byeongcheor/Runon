package com.ict.finalproject.dao;


public interface testDAO {

    public String selectAll();
}
