package com.ict.finalproject.dao;

import com.ict.finalproject.vo.MemberVO;

public interface MypageDAO {
    public MemberVO selectMember(String username);
}
