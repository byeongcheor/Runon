package com.ict.finalproject.service;

import com.ict.finalproject.vo.MemberVO;

public interface MypageService {
    public MemberVO selectMember(String username);
}
