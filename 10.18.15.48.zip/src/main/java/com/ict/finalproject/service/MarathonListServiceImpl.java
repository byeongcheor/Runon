package com.ict.finalproject.service;

import org.springframework.stereotype.Service;

@Service
public class MarathonListServiceImpl implements MarathonListService{
}
