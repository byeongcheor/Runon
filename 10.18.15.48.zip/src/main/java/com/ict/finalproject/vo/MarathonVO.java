package com.ict.finalproject.vo;

public class MarathonVO {
}
