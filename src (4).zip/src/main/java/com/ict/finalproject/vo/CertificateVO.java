package com.ict.finalproject.vo;

public class CertificateVO {
    private int certificate_code;
    private String proof_photo;
    private String application_date;
    private int is_updated;
    private String updated_date;
    private String result_status;
    private String result_date;
    private int order_code;
}
