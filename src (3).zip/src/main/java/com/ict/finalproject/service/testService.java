package com.ict.finalproject.service;

import io.jsonwebtoken.Claims;

public interface testService {

    public String selectAll();
//    public Claims extractAllClaims(String token);
//    public String extractUserid(String token);

}
