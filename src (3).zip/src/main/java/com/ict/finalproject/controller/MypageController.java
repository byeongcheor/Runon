package com.ict.finalproject.controller;


import com.ict.finalproject.dao.MemberDAO;
import com.ict.finalproject.jwt.JWTUtil;
import com.ict.finalproject.service.MemberService;
import com.ict.finalproject.service.MypageService;

import com.ict.finalproject.vo.MemberVO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


@Slf4j
@Controller
public class MypageController {
    @Autowired
    MypageService service;
    @Autowired
    MemberService memberservice;
    @Autowired
    JWTUtil jwtUtil;
    @Autowired
    private MemberDAO memberDAO;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    //유저정보보여주기(마이페이지홈, 회원정보수정)
    @PostMapping("mypage/myHome")
    @ResponseBody
    public MemberVO myHomegetToken(@RequestParam("Authorization")String token, Model model) {
        token=token.substring("Bearer ".length());
        String username=jwtUtil.setTokengetUsername(token);
        MemberVO member = service.selectMember(username);
        String imgname = service.getProfileImg(username);
        String defaultImg = "/basicsimg.png";
        if(username != null){
            model.addAttribute("userimg", imgname != null ? imgname : defaultImg);
        }
        log.info("member:"+member);
        return member;
    }

    //프로필업데이트
    @PostMapping("/mypage/updateProfile")
    @ResponseBody
    public ResponseEntity<Map<String, String>> updateProfile(
            @RequestParam("profile_img") MultipartFile file,
            @RequestHeader("Authorization") String token,
            Model model, HttpSession session, HttpServletRequest request) {

        log.info("파일 업로드 요청수신");
        String UPLOAD_DIR = session.getServletContext().getRealPath("/resources/uploadfile/");
        log.info(UPLOAD_DIR);
        String webPath = request.getContextPath()+ "/resources/uploadfile/";
        log.info("webPath:"+webPath);
        if (file.isEmpty()) {
            log.warn("업로드된 파일이 비어있음");
            Map<String, String> response = new HashMap<String, String>();
            response.put("error", "파일이 비어있습니다.");
            return ResponseEntity.badRequest().body(response);
        }
        try{
            String fileName = file.getOriginalFilename();
            File targetFile = new File(UPLOAD_DIR+fileName);
            log.info("파일저장경로: {}", targetFile.getAbsolutePath());
            file.transferTo(targetFile);
            log.info("파일저장성공: {}", fileName);

            token=token.substring("Bearer ".length());
            String username=jwtUtil.setTokengetUsername(token);
            log.info("username:"+username);

            if(username != null){
                log.info("업뎃시작");
                service.updateProfile(username, fileName);
                log.info("업뎃완료");

                String fileUrl = webPath+fileName;
                session.setAttribute("imgname", fileUrl);
                log.info("세션이미지업뎃완:{}", fileUrl);

                Map<String, String> response = new HashMap<String, String>();
                response.put("imgUrl", fileUrl);
                log.info("test"+response);
                return ResponseEntity.ok().body(response);
            }else{
                log.warn("username is null");
                Map<String, String> response = new HashMap<>();
                response.put("error", "username is null");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        }catch(IOException e){
            log.error("파일 업로드 중 오류 발생", e);
            Map<String, String> response = new HashMap<String, String>();
            response.put("error", "파일 업로드 실패");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }

    }
    //마이페이지로 이동
    @GetMapping ("mypage/myHome")
    public String myHome(){
        String url="mypage/myHome";
        System.out.println(url);
        return url;
       // return "mypage/myHome";
    }
    //구매내역으로 이동
    @GetMapping("mypage/purchaseList")
    public String purchaseList(){

        return "mypage/purchaseList";
    }
    //회원정보수정(DB)
    @PostMapping("/mypage/editProfile")
    public String editProfile(@RequestParam("Authorization")String token){
        token=token.substring("Bearer ".length());
        String username=jwtUtil.setTokengetUsername(token);
        MemberVO member = service.selectMember(username);

        service.editProfile(member);
        return "mypage/editProfile";
    }




}
