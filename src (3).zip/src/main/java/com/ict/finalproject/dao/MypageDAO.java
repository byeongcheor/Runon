package com.ict.finalproject.dao;

import com.ict.finalproject.vo.MemberVO;

public interface MypageDAO {
    public MemberVO selectMember(String username);
    public void updateProfile(String username, String profile_img);
    public String getProfileImg(String username);
    public int editProfile(MemberVO member);
}
